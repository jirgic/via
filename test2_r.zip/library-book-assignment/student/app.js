// Library Book Manager — student starter file
// Implement the required functionality yourself using fetch() and DOM manipulation.

const API_URL = '/api/books';

const form = document.querySelector('#book-form');
const bookList = document.querySelector('#book-list');
const message = document.querySelector('#message');
const saveButton = document.querySelector('#save-button');
const cancelButton = document.querySelector('#cancel-button');
const searchInput = document.querySelector('#search');

// TODO 1: GET /api/books and render the books when the page loads.
// TODO 2: POST /api/books to create a new book from the form.
// TODO 3: PUT /api/books/:id to edit an existing book.
// TODO 4: DELETE /api/books/:id after confirmation.
// TODO 5: Handle API errors, validate inputs, and refresh the DOM.
// BONUS: Filter books by title or author as the user types.
