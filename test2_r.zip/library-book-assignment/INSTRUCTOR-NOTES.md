# Instructor notes — not for student distribution

Suggested duration: 90 minutes. Starter includes an operational zero-dependency Node.js backend, sample in-memory data, HTML/CSS, and a deliberately unfinished `student/app.js`.

## Grading rubric (100 points)
| Area | Points |
| --- | ---: |
| GET — Display books | 20 |
| POST — Add book | 20 |
| PUT — Edit book | 25 |
| DELETE — Remove book | 20 |
| Error handling and testing | 10 |
| DOM manipulation | 5 |
| **Total** | **100** |

Do not grade code quality separately. Optional live search bonus: **+10**, reported separately in brackets, excluded from base 100.

## Suggested checks
1. Initial page fetch displays three sample books and their availability.
2. Creating a valid book displays it without reloading.
3. Editing updates the correct book and Cancel Edit resets mode.
4. Canceling a delete leaves the book unchanged; confirming deletes it.
5. Empty title/author are rejected, and API failures are handled.
6. The page updates through JavaScript DOM manipulation.
7. Bonus search filters titles and authors as the user types.

Data resets on server restart. Run `node server/server.js` from the package root.
