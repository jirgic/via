# Assignment: Library Book Management System

**Technology:** HTML, CSS, JavaScript, REST API  
**Suggested time:** 90 minutes

## Objective
Build the frontend of a library management application using the provided REST API. Practice `fetch()`, asynchronous JavaScript, CRUD operations, and DOM manipulation. You do **not** need to implement the backend.

## Setup
1. Install Node.js (version 18 or newer recommended).
2. Open a terminal in the `library-book-assignment` folder.
3. Run `node server/server.js`.
4. Open **http://localhost:3000** in your browser.
5. Edit `student/app.js` to complete the assignment. The HTML and CSS are provided.

The server stores data **in memory**. Restarting it restores the original sample books. No npm install, database, or internet connection is required.

## API
Base URL: `http://localhost:3000`

| Method | Endpoint | Purpose |
| --- | --- | --- |
| GET | `/api/books` | Retrieve all books |
| GET | `/api/books/:id` | Retrieve one book |
| POST | `/api/books` | Create a book |
| PUT | `/api/books/:id` | Update a book |
| DELETE | `/api/books/:id` | Delete a book |

Example book:

```json
{
  "id": 1,
  "title": "Clean Code",
  "author": "Robert C. Martin",
  "year": 2008,
  "available": true
}
```

The server generates the `id`. For POST and PUT, send the other four fields as JSON, with the `Content-Type: application/json` header. `year` must be an integer between 0 and 2100; `available` must be a Boolean (`true` or `false`, not a string). Invalid data returns HTTP 400 with an `error` message. Missing book IDs return HTTP 404. Successful DELETE returns a JSON confirmation.

## Tasks

### 1. Display books (GET)
- Fetch all books when the page loads.
- Show each book's title, author, publication year, and availability (`Available` or `Borrowed`).
- Show `No books found` when the collection is empty.
- Add working Edit and Delete buttons to each displayed book.

### 2. Add a book (POST)
- Read title, author, year, and availability from the form.
- Send a POST request with a JSON body and appropriate headers.
- Refresh the displayed list after success.
- Clear the form after a successful submission.

### 3. Edit a book (PUT)
- Clicking Edit should populate the form with the selected book's data.
- Let the user change title, author, year, and availability.
- Submit changes with PUT to the correct book ID.
- Refresh the list after success.
- Implement Cancel Edit to return to adding mode.

### 4. Delete a book (DELETE)
- Confirm with the user before deletion.
- Send DELETE to the correct book ID.
- Refresh the displayed list after success.

### 5. Error handling and testing
- Handle failed requests and display helpful error messages.
- Prevent empty title or author values.
- Test all four API operations.

### 6. DOM manipulation
- Build the displayed book list dynamically with JavaScript.
- Update the page after API operations without a full-page reload.
- Attach working event handlers to dynamically created buttons.

## Optional bonus: Live search
Implement the provided search input so it filters displayed books by title or author as the user types, without reloading the page.

## Submission
Submit your completed `student/app.js` file. You may also submit other files if you intentionally changed them. Do not submit `node_modules` or generated dependencies.

## Notes
- Use `fetch()` for HTTP requests.
- Check `response.ok` to detect HTTP errors.
- Do not hardcode the sample books in the frontend.
- The provided server is already complete; do not change its behavior.
