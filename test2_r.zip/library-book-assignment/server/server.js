const http = require('http');
const fs = require('fs');
const path = require('path');
const PORT = Number(process.env.PORT) || 3000;
let books = [
  { id: 1, title: 'Clean Code', author: 'Robert C. Martin', year: 2008, available: true },
  { id: 2, title: '1984', author: 'George Orwell', year: 1949, available: false },
  { id: 3, title: 'The Hobbit', author: 'J. R. R. Tolkien', year: 1937, available: true }
];
let nextId = 4;
const root = path.resolve(__dirname, '..', 'student');
function send(res, status, data) {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS', 'Access-Control-Allow-Headers': 'Content-Type' });
  res.end(JSON.stringify(data));
}
function validBook(body) {
  return body && typeof body.title === 'string' && body.title.trim() && typeof body.author === 'string' && body.author.trim() && Number.isInteger(body.year) && body.year >= 0 && body.year <= 2100 && typeof body.available === 'boolean';
}
function readBody(req) {
  return new Promise((resolve, reject) => {
    let raw = '';
    req.on('data', chunk => { raw += chunk; if (raw.length > 100000) { reject(new Error('Request body too large')); req.destroy(); } });
    req.on('end', () => { try { resolve(JSON.parse(raw)); } catch { reject(new Error('Invalid JSON')); } });
    req.on('error', reject);
  });
}
const server = http.createServer(async (req, res) => {
  if (req.method === 'OPTIONS') return send(res, 204, null);
  const pathname = new URL(req.url, 'http://localhost').pathname;
  const match = pathname.match(/^\/api\/books\/(\d+)$/);
  if (pathname === '/api/books' || match) {
    const id = match ? Number(match[1]) : null;
    const index = match ? books.findIndex(b => b.id === id) : -1;
    if (req.method === 'GET') {
      if (!match) return send(res, 200, books);
      return index === -1 ? send(res, 404, { error: 'Book not found' }) : send(res, 200, books[index]);
    }
    if (req.method === 'POST' && !match) {
      try {
        const body = await readBody(req);
        if (!validBook(body)) return send(res, 400, { error: 'Provide title, author, integer year (0-2100), and boolean available' });
        const book = { id: nextId++, title: body.title.trim(), author: body.author.trim(), year: body.year, available: body.available };
        books.push(book);
        return send(res, 201, book);
      } catch (e) { return send(res, 400, { error: e.message }); }
    }
    if (req.method === 'PUT' && match) {
      if (index === -1) return send(res, 404, { error: 'Book not found' });
      try {
        const body = await readBody(req);
        if (!validBook(body)) return send(res, 400, { error: 'Provide title, author, integer year (0-2100), and boolean available' });
        books[index] = { id, title: body.title.trim(), author: body.author.trim(), year: body.year, available: body.available };
        return send(res, 200, books[index]);
      } catch (e) { return send(res, 400, { error: e.message }); }
    }
    if (req.method === 'DELETE' && match) {
      if (index === -1) return send(res, 404, { error: 'Book not found' });
      books.splice(index, 1);
      return send(res, 200, { message: 'Book deleted' });
    }
    return send(res, 405, { error: 'Method not allowed' });
  }
  if (req.method !== 'GET') return send(res, 405, { error: 'Method not allowed' });
  const filePath = pathname === '/' ? path.join(root, 'index.html') : path.resolve(root, '.' + decodeURIComponent(pathname));
  if (!(filePath === root || filePath.startsWith(root + path.sep))) return send(res, 403, { error: 'Forbidden' });
  fs.readFile(filePath, (err, content) => {
    if (err) return send(res, 404, { error: 'File not found' });
    const ext = path.extname(filePath);
    const type = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8' }[ext] || 'application/octet-stream';
    res.writeHead(200, { 'Content-Type': type });
    res.end(content);
  });
});
server.listen(PORT, () => console.log(`Open http://localhost:${PORT}`));
