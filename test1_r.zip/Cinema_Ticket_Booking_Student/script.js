// Cinema Ticket Booking — student starter file
// Complete the assignment requirements in this file.

const movieData = [
  { id: 1, title: "Interstellar", genre: "Sci-Fi", price: 12 },
  { id: 2, title: "The Dark Knight", genre: "Action", price: 10 },
  { id: 3, title: "Inside Out", genre: "Animation", price: 8 },
  { id: 4, title: "Inception", genre: "Thriller", price: 11 }
];

let bookings = [];
let baseTotal = 0;
let discountActive = false;

function renderMovies() {
  // TODO: Display all movies with a Book Ticket button.
}

function bookTicket(movieId) {
  // TODO: Add a ticket and update the interface.
}

function updateBookingUI() {
  // TODO: Show bookings and the total after any discount.
}

// TODO: Handle the promo code input and Apply Promo button.
// TODO: Call renderMovies() and updateBookingUI() when the page loads.
