const API_URL = '/api/tasks';
const taskList = document.querySelector('#task-list');
const taskForm = document.querySelector('#task-form');
const taskTitle = document.querySelector('#task-title');
const message = document.querySelector('#message');

async function loadTasks() {
  // TODO 1: GET /api/tasks and render each task into #task-list.
  // Each task needs a checkbox, title, and Delete button.
}

async function addTask(title) {
  // TODO 2: POST { title } as JSON to /api/tasks.
  // Refresh the list after success.
}

async function updateTask(id, completed) {
  // TODO 3: PATCH { completed } as JSON to /api/tasks/:id.
  // Refresh the list after success.
}

async function deleteTask(id) {
  // TODO 4: DELETE /api/tasks/:id.
  // Note: successful DELETE returns 204 (no JSON body).
  // Refresh the list after success.
}

taskForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  const title = taskTitle.value.trim();
  if (!title) return;
  await addTask(title);
});

loadTasks();
