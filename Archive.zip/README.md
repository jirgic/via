# Task Manager

1. Open this folder in VS Code or a terminal.
2. Run `node server.js`.
3. Open http://localhost:3000 in your browser.
4. Do not edit `server.js`.

## Objective
Complete a task manager UI using `fetch()`, `async/await`, DOM methods, and JSON.

## API
- `GET /api/tasks` — 200, array of tasks
- `POST /api/tasks` with JSON `{ "title": "New task" }` — 201, created task
- `PATCH /api/tasks/:id` with JSON `{ "completed": true }` — 200, updated task
- `DELETE /api/tasks/:id` — 204, no body

Task: `{ "id": 1, "title": "Example", "completed": false }`
Errors: 400/404 with JSON `{ "error": "..." }`.

## Required tasks and timing
1. Inspect HTML, JavaScript starter, and API using the browser.
2. Implement `loadTasks()` using GET. Render task title, checkbox, Delete button. Attach event handlers.
3. Implement `addTask(title)` using POST; reset the input and refresh after success.
4. Implement `updateTask(id, completed)` using PATCH; refresh after success.
5. Implement `deleteTask(id)` using DELETE; refresh after success.
6. **10 min:** Show loading and error messages; test all operations.

## Submission
Submit `public/script.js` (or the full project ZIP). Tasks are stored in memory and reset when the server restarts.

## Bonus
Show the number of incomplete tasks; disable Add while submitting; show an empty-state message.
