// JavaScript Practical Exam: implement the required functionality below.
// Use vanilla JavaScript and fetch(). Do not use external JS libraries.
const API_URL = 'https://jsonplaceholder.typicode.com/todos';
let tasks = [];

// TODO: Select required DOM elements.
// TODO: Fetch and display the first 10 tasks when the page loads (GET).
// TODO: Implement a renderTasks() function using DOM manipulation.
// TODO: Update total and completed counters.
// TODO: Handle form submission, validate input, and add a task (POST).
// TODO: Handle checkbox changes to update completion (PUT).
// TODO: Handle deletion with confirmation (DELETE).
// TODO: Handle loading states and request errors.
// Note: JSONPlaceholder simulates writes; keep successful changes in local state.
