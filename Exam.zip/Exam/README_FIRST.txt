JAVASCRIPT PRACTICAL EXAM - STUDENT PACKAGE

Read Exam_Instructions.pdf.
Work in the starter/ folder to complete the application.
Open the project in the browser with index.html.

Duration: 3 hours. Total: 100 points, plus optional bonus.
No solutions are included.
